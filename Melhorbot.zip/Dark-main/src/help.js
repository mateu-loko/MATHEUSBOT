const help = (prefix) => {
	return `

╔════════════════════
║        🌹𝐁𝐎𝐓🌹
╠════════════════════


➸ Prefix:  *「${prefix} 」*
➸ Status: *「 Online 」*

       • ──── ✾ ──── •
       *FIGURINHAS*【✔】
       • ──── ✾ ──── •
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ útil em : converter imagem/gif/vídeo em adesivo
➸ uso : responder imagem/gif/video ou enviar imagem/gif/video com legenda\n
➸ Comando : *${prefix}sticker nobg* ou *${prefix}stiker nobg*
➸ útil em : converter imagem em adesivo removendo o fundo
➸ uso : responder imagem ou enviar imagem com legenda/n
➸ Comando : *${prefix}toimg*
➸ útil em : converter adesivo em imagem
➸ uso : adesivo de resposta\n
➸ Comando : *${prefix}tsticker* ou *${prefix}tstiker*
➸ útil em : converter texto em adesivo
➸ uso : *${prefix}tsticker seu texto aqui*\n

       • ─── ✾ ─── •
       *MEMES*【✔】
       • ─── ✾ ─── •
      
➸ Comando : *${prefix}meme*
➸ útil em : mandar imagens aleatórias de meme [inglês]
➸ uso : basta emviar o comando\n
➸ Comando : *${prefix}memeindo*
➸ útil em : mandar imagens aleatórias de meme [indo]
➸ uso : basta enviar o comando

       • ──── ✾ ──── •
       *OUTROS...*【✔】
       • ──── ✾ ──── •
      
➸ Comando : *${prefix}gtts*
➸ útil em : converter texto em fala/áudio
➸ uso : *${prefix}gtts [cc] [text]*\nexemplo : *${prefix}gtts ja On2-chan*\n
➸ Comando : *${prefix}loli*
➸ útil em : mandar imagens aleatórias de loli
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}nsfwloli*
➸ útil em : mandar imagens aleatórias de nsfw loli
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}url2img*
➸ útil em : tirar screenshots da web
➸ uso : *${prefix}url2img [tipe] [url]*\n
➸ Comando : *${prefix}simi*
➸ útil em : responder sua mensagem por simi
➸ uso : *${prefix}simi sua mensagem*\n
➸ Comando : *${prefix}ocr*
➸ útil em : pegar o texto da foto e lhe enviar
➸ uso : responder imagem ou enviar mensagem com legenda\n
➸ Comando : *${prefix}wait*
➸ útil em : pesquisar sobre o anime por imagem [ Que anime é este/que ]
➸ uso : responder imagem ou enviar imagem com legenda\n
➸ Comando : *${prefix}setprefix*
➸ útil em : alterar o prefixo do bot
➸ uso : *${prefix}setprefix [texto|opcional]*\nexemplo : *${prefix}setprefix ?*
➸ Nota : Usado somente pelo proprietário do bot\n

       • ─── ✾ ─── •
       *GRUPO*【✔】
       • ─── ✾ ─── •
      
➸ Comando : *${prefix}linkgroup*
➸ útil em : enviar o link do grupo
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}marcar*
➸ útil em : marcar todos os membros do grupo, incluindo administradores
➸ uso : basta enviar o comando\n
➸ Nota : Você precisa ser administrador do grupo\n
➸ Comando : *${prefix}simih*
➸ útil em : ativar o modo simi no grupo
➸ uso : *${prefix}simih 1* para ativar o modo simi e *${prefix}simih 0* para 
➸ desativar o modo simih
➸ Nota : Você precisa ser administrador do grupo\n
➸ Comando : *${prefix}add*
➸ útil em : adicionar membro ao grupo
➸ uso : *${prefix}add 5585xxxxx*\n
➸ Nota : o bot precisa ser admin!\n
➸ Comando : *${prefix}kick*
➸ útil em : remover membros do grupo
➸ uso : *${prefix}kick e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}promote*
➸ útil em : tornar membro do grupo um administrador
➸ uso : *${prefix}promote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}demote*
➸ útil em : tornar o administrador um membro comum
➸ uso : *${prefix}demote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também

       • ────── ✾ ────── •
       *MENU DO MATEU*【✔】
       • ────── ✾ ────── •              

╔════════════════════
  DONO DO BOT *🔥mateu🔥*
  DUVIDAS? 👇
  WA.me/+1 (579) 996-8046
╚════════════════════`
}

exports.help = help






